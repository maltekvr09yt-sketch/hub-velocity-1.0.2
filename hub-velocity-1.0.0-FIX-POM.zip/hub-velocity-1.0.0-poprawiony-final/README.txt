HUB-VELOCITY 1.0.0 - FINAL

Plugin dla Velocity 4.x / Java 25+.

Funkcje:
- /teleporthub: wybiera losowo dostepny hub1/hub2
- limit 100 graczy na hub
- sprawdzanie pingiem
- automatyczna proba drugiego huba
- komunikat: Nie udało się połączyć z danym serwerem
- /hubstatus

Backendy w velocity.toml musza nazywac sie dokladnie:
hub1
hub2

WAŻNE:
Ten ZIP jest PROJEKTEM do zbudowania przez GitHub Actions.
Workflow dodatkowo sprawdza, czy gotowy JAR zawiera velocity-plugin.json.
Nie wrzucaj samego ZIP-a do plugins/.

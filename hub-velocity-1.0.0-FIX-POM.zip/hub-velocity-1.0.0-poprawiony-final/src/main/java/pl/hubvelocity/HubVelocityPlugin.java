package pl.hubvelocity;

import com.google.inject.Inject;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.proxy.ConnectionRequestBuilder;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.ServerConnection;
import com.velocitypowered.api.proxy.messages.ChannelIdentifier;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import net.kyori.adventure.text.Component;
import org.slf4j.Logger;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

@Plugin(id = "hub-velocity", name = "Hub-Velocity", version = "1.0.0", authors = {"Hub"})
public final class HubVelocityPlugin {
    private static final String HUB1 = "hub1";
    private static final String HUB2 = "hub2";
    private static final int MAX_PLAYERS = 100;
    private static final String FAIL_MESSAGE = "Nie udało się połączyć z danym serwerem";

    private final ProxyServer proxy;
    private final Logger logger;
    private final ChannelIdentifier channel =
            MinecraftChannelIdentifier.from("hubvelocity:connect");

    @Inject
    public HubVelocityPlugin(ProxyServer proxy, Logger logger) {
        this.proxy = proxy;
        this.logger = logger;
    }

    @Subscribe
    public void onProxyInitialization(ProxyInitializeEvent event) {
        proxy.getChannelRegistrar().register(channel);
        proxy.getCommandManager().register(
                proxy.getCommandManager().metaBuilder("hubstatus").build(),
                new HubStatusCommand()
        );
        logger.info("Hub-Velocity 1.0.0 wlaczony.");
    }

    @Subscribe
    public void onPluginMessage(PluginMessageEvent event) {
        if (!event.getIdentifier().equals(channel)) return;
        event.setResult(PluginMessageEvent.ForwardResult.handled());

        if (!(event.getSource() instanceof ServerConnection connection)) return;

        String message = new String(event.getData(), StandardCharsets.UTF_8);
        if (!message.equalsIgnoreCase("teleporthub")) return;

        connectToAvailableHub(connection.getPlayer());
    }

    private void connectToAvailableHub(Player player) {
        List<RegisteredServer> available = new ArrayList<>();
        addIfAvailable(available, HUB1);
        addIfAvailable(available, HUB2);

        if (available.isEmpty()) {
            player.disconnect(Component.text(FAIL_MESSAGE));
            return;
        }

        Collections.shuffle(available, ThreadLocalRandom.current());
        tryNextServer(player, available, 0);
    }

    private void tryNextServer(Player player, List<RegisteredServer> servers, int index) {
        if (index >= servers.size()) {
            player.disconnect(Component.text(FAIL_MESSAGE));
            return;
        }

        RegisteredServer target = servers.get(index);

        target.ping().whenComplete((ping, pingError) -> {
            if (pingError != null) {
                tryNextServer(player, servers, index + 1);
                return;
            }

            player.createConnectionRequest(target).connect().whenComplete((result, connectError) -> {
                if (connectError != null || result == null ||
                        result.getStatus() != ConnectionRequestBuilder.Status.SUCCESS) {
                    tryNextServer(player, servers, index + 1);
                }
            });
        });
    }

    private void addIfAvailable(List<RegisteredServer> list, String name) {
        Optional<RegisteredServer> server = proxy.getServer(name);
        if (server.isEmpty()) return;

        if (server.get().getPlayersConnected().size() < MAX_PLAYERS) {
            list.add(server.get());
        }
    }

    private final class HubStatusCommand implements SimpleCommand {
        @Override
        public void execute(Invocation invocation) {
            if (!(invocation.source() instanceof Player player)) {
                invocation.source().sendPlainMessage("Ta komenda jest tylko dla graczy.");
                return;
            }

            player.sendPlainMessage("hub1: " + status(HUB1));
            player.sendPlainMessage("hub2: " + status(HUB2));
        }

        private String status(String name) {
            Optional<RegisteredServer> server = proxy.getServer(name);
            if (server.isEmpty()) return "NIEDOSTEPNY";
            return server.get().getPlayersConnected().size() + "/" + MAX_PLAYERS;
        }
    }
}
